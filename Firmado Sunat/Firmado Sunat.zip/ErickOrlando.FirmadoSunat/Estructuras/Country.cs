﻿using System;

namespace ErickOrlando.FirmadoSunat.Estructuras
{
    [Serializable]
    public class Country
    {
        public string IdentificationCode { get; set; }
    }
}