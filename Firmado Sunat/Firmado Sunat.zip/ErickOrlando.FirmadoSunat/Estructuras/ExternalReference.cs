﻿using System;

namespace ErickOrlando.FirmadoSunat.Estructuras
{
    [Serializable]
    public class ExternalReference
    {
        public string URI { get; set; }
    }
}