﻿using System;

namespace ErickOrlando.FirmadoSunat.Estructuras
{
    [Serializable]
    public class Payment
    {
        public string PaidDate { get; set; }
        public string ID { get; set; }
        public PayableAmount PaidAmount { get; set; }

        public Payment()
        {
            PaidAmount = new PayableAmount();
            ID = "0001";
        }
    }
}