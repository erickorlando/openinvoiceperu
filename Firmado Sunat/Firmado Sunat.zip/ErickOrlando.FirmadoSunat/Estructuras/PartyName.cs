﻿using System;

namespace ErickOrlando.FirmadoSunat.Estructuras
{
    [Serializable]
    public class PartyName
    {
        public string Name { get; set; }
    }
}