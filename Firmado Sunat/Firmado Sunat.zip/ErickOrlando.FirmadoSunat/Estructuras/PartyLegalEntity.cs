﻿using System;

namespace ErickOrlando.FirmadoSunat.Estructuras
{
    [Serializable]
    public class PartyLegalEntity
    {
        public string RegistrationName { get; set; }
    }
}