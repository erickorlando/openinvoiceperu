﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ErickOrlando.FirmadoSunat.Entidades.Core
{
    public abstract class DTOBaseRequest
    {
        public string NombreBaseDatos { get; set; }
    }
}
