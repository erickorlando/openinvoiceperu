﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ErickOrlando.FirmadoSunat.Entidades.Core
{
    public class DTOBaseResponse
    {
        public ComunResponse Respuesta { get; set; }

        public DTOBaseResponse()
        {
            Respuesta = new ComunResponse();
        }

        public void GrabarLog()
        {
            Console.Write(Respuesta.ToString());
            System.Diagnostics.Trace.Write(Respuesta.ToString());
        }
    }
}
