﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ErickOrlando.FirmadoSunat.Entidades.Core
{
    public class ComunResponse
    {
        public string Codigo { get; set; }
        public string Mensaje { get; set; }
        public string MensajeTecnico { get; set; }
        public string PilaLlamadas { get; set; }

        public override string ToString()
        {
            return $"{Codigo}: {Mensaje} => {MensajeTecnico} {PilaLlamadas}";
        }
    }
}
