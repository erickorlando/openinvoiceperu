﻿using System;
using System.Data.Entity.Infrastructure;
using System.Data.Entity.Validation;
using System.Linq;
using System.Text;
using ErickOrlando.Datos;
using ErickOrlando.Entidades;
using ErickOrlando.Entidades.Constantes;
using ErickOrlando.Entidades.DTO;
using ErickOrlando.Entidades.Estructuras;
using ErickOrlando.FirmadoSunat.Constantes;
using ErickOrlando.FirmadoSunat.Entidades.DTO;
using ErickOrlando.FirmadoSunat.Estructuras;
using ErickOrlando.Generador;

namespace ErickOrlando.FirmadoSunat
{
    public partial class ErickOrlandoService
    {

        public DTODocumentoSunatResponse GenerarTramaRetencion(DTODocumentoSunatRequest request)
        {
            var response = new DTODocumentoSunatResponse();

            try
            {
                using (var ctx = new plantilla_fedbEntities(request.NombreBaseDatos))
                {
                    // Buscamos los Documentos de Retencion en Base al ID.
                    var docRetenciones = from doc in ctx.GP_CE_TRX_RETENCION
                                         where doc.GP_CE_ID == request.IdDocumento
                                         select doc;

                    var documento = docRetenciones.First();

                    if (documento == null)
                        throw new InvalidOperationException("No se encontró el documento");

                    var serieDocumento = int.Parse(documento.GP_CE_ID.Split('-').First()).ToString("00#");
                    var numeroDocumento = documento.GP_CE_ID.Split('-').Last().Trim();
                    var idCompletoDocumento = string.Concat("R", serieDocumento, "-", numeroDocumento);

                    var nombreArchivo = $"{documento.GP_CE_PARTYID}-20-R{serieDocumento}-{numeroDocumento}";

                    #region Generacion de Retencion

                    var retencionDoc = new Retention
                    {
                        Signature = new SignatureCac
                        {
                            ID = "IDSignTSR",
                            SignatoryParty = new SignatoryParty
                            {
                                PartyIdentification = new PartyIdentification
                                {
                                    ID = new PartyIdentificationID
                                    {
                                        value = documento.GP_CE_PARTYID.Trim()
                                    }
                                },
                                PartyName = new PartyName
                                {
                                    Name = documento.GP_CE_PARTYNAME.Trim()
                                },
                            },
                            DigitalSignatureAttachment = new DigitalSignatureAttachment
                            {
                                ExternalReference = new ExternalReference
                                {
                                    URI = "#IDSignTSR",
                                }
                            }
                        },
                        ID = idCompletoDocumento,
                        IssueDate = documento.GP_CE_ISSUEDATE.ToString(Constantes.FormatoFecha),
                        AgentParty = new AgentParty
                        {
                            PartyIdentification = new PartyIdentification
                            {
                                ID = new PartyIdentificationID
                                {
                                    schemeID = documento.GP_CE_PARTYID2,
                                    value = documento.GP_CE_PARTYID
                                }
                            },
                            PartyName = new PartyName
                            {
                                Name = documento.GP_CE_PARTYNAME.Trim()
                            },
                            PostalAddress = new PostalAddress
                            {
                                ID = documento.GP_CE_POSTALADDR.Trim(),
                                StreetName = documento.GP_CE_STREETNAME.Trim(),
                                CitySubdivisionName = documento.GP_CE_CITYSUBDIV.Trim(),
                                CityName = documento.GP_CE_CITYNAME.Trim(),
                                CountrySubentity = documento.GP_CE_COUNTRYSUB.Trim(),
                                District = documento.GP_CE_DISTRICT.Trim(),
                                Country = new Country
                                {
                                    IdentificationCode = documento.GP_CE_COUNTRY.Trim(),
                                }
                            },
                            PartyLegalEntity = new PartyLegalEntity
                            {
                                RegistrationName = documento.GP_CE_PARTYLEGALNAME.Trim()
                            }
                        },
                        ReceiverParty = new ReceiverParty
                        {
                            PartyIdentification = new PartyIdentification
                            {
                                ID = new PartyIdentificationID
                                {
                                    schemeID = documento.GP_CE_RCVRPARTYID2,
                                    value = documento.GP_CE_RCVRPARTYID
                                }
                            },
                            PartyName = new PartyName
                            {
                                Name = documento.GP_CE_RCVRPARTYNAME.Trim()
                            },
                            PostalAddress = new PostalAddress
                            {
                                ID = documento.GP_CE_POSTALADDR2.Trim(),
                                StreetName = documento.GP_CE_STREETNAME2.Trim(),
                                CitySubdivisionName = documento.GP_CE_CITYSUBDIV2.Trim(),
                                CityName = documento.GP_CE_CITYNAME2.Trim(),
                                CountrySubentity = documento.GP_CE_COUNTRYSUB2.Trim(),
                                District = documento.GP_CE_DISTRICT2.Trim(),
                                Country = new Country
                                {
                                    IdentificationCode = documento.GP_CE_COUNTRY2.Trim(),
                                }
                            },
                            PartyLegalEntity = new PartyLegalEntity
                            {
                                RegistrationName = documento.GP_CE_PARTYLEGALNAME2.Trim()
                            }
                        },
                        SUNATRetentionSystemCode = documento.GP_CE_RSC.Trim(),
                        SUNATRetentionPercent = 3,
                        Note = documento.GP_CE_NOTE.Trim(),
                        TotalInvoiceAmount = new PayableAmount
                        {
                            currencyID = documento.GP_CE_CURID,
                            value = documento.GP_CE_INVOICEAMOUNT
                        },
                        TotalPaid = new PayableAmount
                        {
                            currencyID = documento.GP_CE_CURID2,
                            value = documento.GP_CE_TOTALPAID,
                        }
                    };

                    foreach (var item in docRetenciones)
                    {
                        var documentosRelacionados = new SUNATRetentionDocumentReference
                        {
                            ID = new PartyIdentificationID
                            {
                                schemeID = item.GP_CE_RDRID.Trim(),
                                value = item.GP_CE_RDR.Trim().Substring(1)
                            },
                            IssueDate = item.GP_CE_ISSUEDATE2.ToString(Constantes.FormatoFecha),
                            TotalInvoiceAmount = new PayableAmount
                            {
                                currencyID = item.GP_CE_CURID3,
                                value = item.GP_CE_INVOICEAMOUNT2
                            },
                            Payment = new Payment
                            {
                                PaidDate = item.GP_CE_PAIDDATE.ToString(Constantes.FormatoFecha),
                                ID = QuitarLetras(item.GP_CE_PAYNUMBER.Trim()),
                                PaidAmount = new PayableAmount
                                {
                                    currencyID = item.GP_CE_CURID4,
                                    value = item.GP_CE_PAIDAMOUNT
                                }
                            },
                            SUNATRetentionInformation = new SUNATRetentionInformation
                            {
                                SUNATRetentionAmount = new PayableAmount
                                {
                                    currencyID = item.GP_CE_CURID5,
                                    value = item.GP_CE_RETAMOUNT
                                },
                                SUNATRetentionDate = item.GP_CE_RETDATE.ToString(Constantes.FormatoFecha),
                                SUNATNetTotalPaid = new PayableAmount
                                {
                                    currencyID = item.GP_CE_CURID6,
                                    value = item.GP_CE_NETTOTPAID
                                },
                                ExchangeRate = new ExchangeRate
                                {
                                    SourceCurrencyCode = item.GP_CE_SCC,
                                    TargetCurrencyCode = item.GP_CE_TCC,
                                    CalculationRate = item.GP_CE_CALCRATE,
                                    Date = item.GP_CE_XCHDATE.Year < 1950 ? string.Empty : item.GP_CE_XCHDATE.ToString(Constantes.FormatoFecha)
                                }
                            }
                        };

                        retencionDoc.SUNATRetentionDocumentReference.Add(documentosRelacionados);
                    }
                    #endregion

                    //UploadToAzureAsync(documento.GP_CE_PARTYID, retencionDoc, nombreArchivo).Wait();

                    response.NombreArchivo = nombreArchivo;

                    var respuesta = ProcesarRetencionEnSunat(new DTOEnvioDocumentoRequest
                    {
                        NombreArchivo = nombreArchivo,
                        NombreBaseDatos = request.NombreBaseDatos,
                        RucEmisor = documento.GP_CE_PARTYID,
                    });
                    // Ubicamos el registro en la tabla Documentos para luego registrar el Documento Digital.

                    //var cabecera = (from doc in ctx.Documento
                    //                where doc.IDDocumentoOriginal == documento.DEX_ROW_ID
                    //                select doc.ID).FirstOrDefault();

                    //if (!string.IsNullOrEmpty(cabecera))
                    //{

                    //    //EnviarCorreo(docRetenciones);
                    //    // Enviamos el Correo con el PDF Generado.
                    //}
                    response.Respuesta.Codigo = respuesta.Respuesta.Codigo;
                    response.Respuesta.Mensaje = respuesta.Respuesta.Mensaje;

                }
            }
            #region Control de Excepciones
            catch (Exception ex)
            {
                response.Respuesta.Codigo = ErrorGenerico.Codigo;
                response.Respuesta.Mensaje = ErrorGenerico.Mensaje;
                response.Respuesta.MensajeTecnico = $"{ex.GetType().Name} {DesenredarException(ex)}";
                response.Respuesta.PilaLlamadas = ex.StackTrace;
                response.GrabarLog();
            }
            #endregion

            return response;
        }


        /*
                private static void EnviarCorreo(IEnumerable<GP_CE_TRX_RETENCION> datos)
                {
                    var viewer = new LocalReport();
                    Warning[] warnings;
                    string[] streamIds;
                    string mimeType;
                    string encoding;
                    string filenameExtension;

                    // Cargamos el reporte con data.
                    var ds = new RetencionDataset();
                    var retenciones = datos as IList<GP_CE_TRX_RETENCION> ?? datos.ToList();
                    var primero = retenciones.First();
                    string direccion = $"{primero.GP_CE_STREETNAME} {primero.GP_CE_COUNTRYSUB} {primero.GP_CE_DISTRICT}";

                    ds.ReporteRetencion.AddReporteRetencionRow(primero.GP_CE_ID.Split('-').First(), primero.GP_CE_ID.Split('-').Last(), primero.GP_CE_PARTYID, direccion, "(511)326-1234", "(511)326-4542", primero.GP_CE_RCVRPARTYNAME, primero.GP_CE_RCVRPARTYID, primero.GP_CE_ISSUEDATE, primero.GP_CE_CALCRATE, primero.GP_CE_NOTE, NumLetra.Convertir(Math.Round(primero.GP_CE_TOTALPAID, 2).ToString(CultureInfo.InvariantCulture), true, "soles"));

                    foreach (var doc in retenciones)
                    {
                        for (int i = 0; i < 3; i++)
                        {
                            string pie = string.Empty;
                            switch (i)
                            {
                                case 0:
                                    pie = "EMISOR";
                                    break;
                                case 1:
                                    pie = "PROVEEDOR";
                                    break;
                                case 2:
                                    pie = "SUNAT";
                                    break;
                            }
                            ds.RetencionDetalle.AddRetencionDetalleRow(doc.GP_CE_RDR, doc.GP_CE_ISSUEDATE2, doc.GP_CE_PAIDAMOUNT, doc.GP_CE_CURID2, doc.GP_CE_RETAMOUNT, doc.GP_CE_PAYNUMBER, pie);
                        }
                    }

                    viewer.DataSources.Add(new ReportDataSource("dsReporteRetencion", ds.ReporteRetencion.ToList()));
                    viewer.DataSources.Add(new ReportDataSource("dsDetalle", ds.RetencionDetalle.ToList()));
                    viewer.Refresh();
                    viewer.ReportPath = "./Reportes/ComprobanteRetencion.rdlc";
                    byte[] bytes = viewer.Render("PDF", null, out mimeType, out encoding,
                        out filenameExtension, out streamIds, out warnings);

                    var correo = new MailMessage { From = new MailAddress("solucionescloud@insideb2b.com") };

                    correo.To.Add(new MailAddress("evelasco@insideb2b.com", "Erick Orlando"));
                    correo.Subject = "Documento de Retencion";
                    correo.Attachments.Add(new Attachment(new MemoryStream(bytes), $"R{primero.GP_CE_ID}.pdf"));

                    correo.Body = $"Estimado usuario se le envia su documento de Retención N° {primero.GP_CE_ID}";

                    using (var cliente = new SmtpClient("smtp.office365.com"))
                    {
                        cliente.EnableSsl = true;
                        cliente.Port = 587;
                        cliente.Credentials = new System.Net.NetworkCredential("solucionescloud@insideb2b.com", "B2B16fact");
                        cliente.Send(correo);
                    }
                }
        */

        public DTOEnvioDocumentoResponse ProcesarRetencionEnSunat(DTOEnvioDocumentoRequest request)
        {
            var response = new DTOEnvioDocumentoResponse();
            try
            {
                // Obtenemos una tupla con el usuario y password de la clave SOL SUNAT.
                var datosSol = ObtenerDatosSol(request.RucEmisor);

                using (var conexion = new Connect(request.RucEmisor, datosSol.Item1, datosSol.Item2, "ServicioSunatRetenciones"))
                {

                    var tramaZip = DownloadFromAzureAsync(request.NombreArchivo).Result;

                    var resultado = conexion
                        .EnviarDocumento(tramaZip, string.Concat(request.NombreArchivo, ".zip"));

                    if (resultado.Item2)
                    {
                        // La respuesta la guardamos como Blob en Azure.
                        UploadToAzureAsync(request.NombreArchivo, Convert.FromBase64String(resultado.Item1));

                        response.Respuesta.Codigo = MensajeExitoso.Codigo;
                        response.Respuesta.Mensaje = EnvioSunatCorrecto;
                    }
                    else
                    {
                        response.Respuesta.Codigo = ErrorSUNAT.Codigo;
                        response.Respuesta.Mensaje = $"{ErrorSUNAT.Mensaje} {resultado.Item1}";
                    }
                }

            }
            #region Control de Excepciones
            catch (DbEntityValidationException ex)
            {
                StringBuilder sb = new StringBuilder();

                foreach (var failure in ex.EntityValidationErrors)
                {
                    sb.AppendFormat("{0} Errores de Validación\n", failure.Entry.Entity.GetType());
                    foreach (var error in failure.ValidationErrors)
                    {
                        sb.AppendFormat("- {0} : {1}", error.PropertyName, error.ErrorMessage);
                        sb.AppendLine();
                    }
                }

                response.Respuesta.Codigo = ErrorValidacion.Codigo;
                response.Respuesta.Mensaje = ErrorValidacion.Mensaje;
                response.Respuesta.MensajeTecnico = sb.ToString();
                sb.Length = 0;
                response.Respuesta.PilaLlamadas = ex.StackTrace;
                response.GrabarLog();
            }
            catch (DbUpdateException ex)
            {
                response.Respuesta.Codigo = ErrorBaseDatos.Codigo;
                response.Respuesta.Mensaje = ErrorBaseDatos.Mensaje;
                response.Respuesta.MensajeTecnico = $"{ex.GetType().Name} {DesenredarException(ex)}";
                response.Respuesta.PilaLlamadas = ex.StackTrace;
                response.GrabarLog();
            }
            catch (Exception ex)
            {
                response.Respuesta.Codigo = ErrorGenerico.Codigo;
                response.Respuesta.Mensaje = ErrorGenerico.Mensaje;
                response.Respuesta.MensajeTecnico = $"{ex.GetType().Name} {DesenredarException(ex)}";
                response.Respuesta.PilaLlamadas = ex.StackTrace;
                response.GrabarLog();
            }
            #endregion

            return response;
        }


    }
}