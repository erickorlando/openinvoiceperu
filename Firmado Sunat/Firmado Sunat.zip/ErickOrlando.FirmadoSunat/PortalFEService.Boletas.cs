﻿using System;
using System.Collections.Generic;
using System.Data.Entity.Infrastructure;
using System.Data.Entity.Validation;
using System.Linq;
using System.Text;
using ErickOrlando.Datos;
using ErickOrlando.Entidades;
using ErickOrlando.Entidades.Constantes;
using ErickOrlando.Entidades.DTO;
using ErickOrlando.Entidades.Estructuras;
using ErickOrlando.FirmadoSunat.Constantes;
using ErickOrlando.FirmadoSunat.Entidades.DTO;
using ErickOrlando.FirmadoSunat.Estructuras;

namespace ErickOrlando.FirmadoSunat
{
    public partial class ErickOrlandoService
    {


        public DTODocumentoSunatResponse GenerarTramaBoleta(DTODocumentoSunatRequest request)
        {
            var response = new DTODocumentoSunatResponse();
            try
            {
                using (var ctx = new plantilla_fedbEntities(request.NombreBaseDatos))
                {
                    var docFacturas = from doc in ctx.IB2B_PFE_Boleta
                                      where doc.F07_0_SerieCorrelativo == request.IdDocumento
                                      orderby doc.F29_0_LineID
                                      select doc;

                    var documento = docFacturas.First();

                    if (documento == null)
                        throw new InvalidOperationException("No se encontró el documento");

                    var serieDocumento = documento.F07_0_SerieCorrelativo.Split('-').First().PadLeft(4, 'B');
                    var numeroDocumento = documento.F07_0_SerieCorrelativo.Split('-').Last().Trim() + request.Intento;
                    var idCompletoDocumento = string.Concat(serieDocumento, "-", numeroDocumento.Substring(numeroDocumento.Length - 8));

                    var nombreArchivo = $"{documento.F05_0_SuplierCustomerAssignedAccountID}-03-{serieDocumento}-{numeroDocumento}";

                    #region Generacion de Boleta

                    var factura = new Invoice
                    {
                        ID = idCompletoDocumento,
                        IssueDate = documento.F01_0_IssueDate ?? DateTime.Now,
                        InvoiceTypeCode = documento.F06_0_InvoiceTypeCode.Trim(),
                        DocumentCurrencyCode = documento.F24_0_DocumentCurrencyCode,
                        Signature = new SignatureCac
                        {
                            ID = $"S{idCompletoDocumento}",
                            SignatoryParty = new SignatoryParty
                            {
                                PartyIdentification = new PartyIdentification
                                {
                                    ID = new PartyIdentificationID
                                    {
                                        value = documento.F05_0_SuplierCustomerAssignedAccountID,
                                        schemeID = documento.F05_1_SuplierAdditionalAccountID
                                    }
                                },
                                PartyName = new PartyName()
                                {
                                    Name = documento.F03_0_SuplierName.Trim()
                                }
                            },
                            DigitalSignatureAttachment = new DigitalSignatureAttachment()
                            {
                                ExternalReference = new ExternalReference()
                                {
                                    URI = $"#S{idCompletoDocumento}-{documento.F03_0_SuplierName}"
                                }
                            }
                        },
                        AccountingSupplierParty = new AccountingSupplierParty
                        {
                            CustomerAssignedAccountID = documento.F05_0_SuplierCustomerAssignedAccountID,
                            AdditionalAccountID = "6",
                            Party = new Party()
                            {
                                PartyName = new PartyName()
                                {
                                    Name = documento.F03_0_SuplierName.Trim(),
                                },
                                PostalAddress = new PostalAddress()
                                {
                                    ID = documento.F04_0_SuplierID.Trim(),
                                    StreetName = documento.F04_1_SuplierStreetName.Trim(),
                                    CitySubdivisionName = documento.F04_2_SuplierCitySubdivisionName.Trim(),
                                    CityName = documento.F04_3_SuplierCityName.Trim(),
                                    CountrySubentity = documento.F04_4_SuplierCountrySubentity.Trim(),
                                    District = documento.F04_5_SuplierDistrict.Trim(),
                                    Country = new Country
                                    {
                                        IdentificationCode = documento.F04_6_SuplierIdentificationCode.Trim()
                                    }
                                },
                                PartyLegalEntity = new PartyLegalEntity
                                {
                                    RegistrationName = documento.F02_0_SuplierRegistrationName.Trim()
                                }
                            }
                        },
                        AccountingCustomerParty = new AccountingSupplierParty
                        {
                            CustomerAssignedAccountID = documento.F08_0_CustomerAssignedAccountID.Trim(),
                            AdditionalAccountID = documento.F08_1_CustomerAdditionalAccountID.Trim(),
                            Party = new Party
                            {
                                PartyLegalEntity = new PartyLegalEntity
                                {
                                    RegistrationName = documento.F09_0_CustomerRegistrationName.Trim(),
                                }
                            }
                        },

                        LegalMonetaryTotal = new LegalMonetaryTotal
                        {
                            AllowanceTotalAmount = new PayableAmount
                            {
                                currencyID = documento.F24_0_DocumentCurrencyCode,
                                value = documento.F41_0_DiscountTotalAmount ?? 0
                            },
                            PayableAmount = new PayableAmount
                            {
                                currencyID = documento.F24_0_DocumentCurrencyCode,
                                // Si hay operaciones gratuitas el precio total es 0.
                                value = documento.F23_0_PayableAmount ?? 0
                            }
                        }
                    };
                    /* 18 - Sumatoria de IGV */
                    factura.TaxTotals.Add(
                     new TaxTotal
                     {
                         TaxAmount = new PayableAmount
                         {
                             currencyID = documento.F24_0_DocumentCurrencyCode,
                             value = documento.F18_1_IGVTaxAmount ?? 0,
                         },
                         TaxSubtotal = new TaxSubtotal
                         {
                             TaxAmount = new PayableAmount
                             {
                                 currencyID = documento.F24_0_DocumentCurrencyCode,
                                 value = documento.F18_1_IGVTaxAmount ?? 0
                             },
                             TaxCategory = new TaxCategory
                             {
                                 TaxScheme = new TaxScheme
                                 {
                                     ID = documento.F18_2_IGVTaxSchemeID.Trim(),
                                     Name = documento.F18_3_IGVTaxSchemeName.Trim(),
                                     TaxTypeCode = documento.F18_4_IGVTaxSchemeTaxTypeCode.Trim()
                                 }
                             }
                         }
                     });
                    /* 19 - Sumatoria de ISC */
                    if (!string.IsNullOrEmpty(documento.F19_2_ISCTaxSchemeID?.Trim()))
                        factura.TaxTotals.Add(
                         new TaxTotal
                         {
                             TaxAmount = new PayableAmount
                             {
                                 currencyID = documento.F24_0_DocumentCurrencyCode,
                                 value = documento.F19_0_ISCTaxAmountID ?? 0,
                             },
                             TaxSubtotal = new TaxSubtotal
                             {
                                 TaxAmount = new PayableAmount
                                 {
                                     currencyID = documento.F24_0_DocumentCurrencyCode,
                                     value = documento.F19_1_ISCTaxAmount ?? 0
                                 },
                                 TaxCategory = new TaxCategory
                                 {
                                     TaxScheme = new TaxScheme
                                     {
                                         ID = documento.F19_2_ISCTaxSchemeID?.Trim(),
                                         Name = documento.F19_3_ISCTaxSchemeName.Trim(),
                                         TaxTypeCode = documento.F19_4_ISCTaxSchemeTaxTypeCode.Trim()
                                     }
                                 }
                             }
                         });
                    /* 20 - Sumatoria de otros tributos */
                    if (!string.IsNullOrEmpty(documento.F20_2_OtherTaxSchemeID?.Trim()))
                        factura.TaxTotals.Add(
                         new TaxTotal
                         {
                             TaxAmount = new PayableAmount
                             {
                                 currencyID = documento.F24_0_DocumentCurrencyCode,
                                 value = documento.F20_0_OtherTaxAmountID ?? 0,
                             },
                             TaxSubtotal = new TaxSubtotal
                             {
                                 TaxAmount = new PayableAmount
                                 {
                                     currencyID = documento.F24_0_DocumentCurrencyCode,
                                     value = documento.F20_1_OtherTaxAmount ?? 0
                                 },
                                 TaxCategory = new TaxCategory
                                 {
                                     TaxScheme = new TaxScheme
                                     {
                                         ID = documento.F20_2_OtherTaxSchemeID?.Trim(),
                                         Name = documento.F20_3_OtherTaxSchemeName.Trim(),
                                         TaxTypeCode = documento.F20_4_OtherTaxSchemeTaxTypeCode.Trim()
                                     }
                                 }
                             }
                         });
                    /* 15 - Total valor de venta - operaciones gravadas */
                    if (!string.IsNullOrEmpty(documento.F15_0_GravadoID?.Trim()))
                    {
                        factura.UblExtensions.Extension2.ExtensionContent
                            .AdditionalInformation.AdditionalMonetaryTotals.Add(new AdditionalMonetaryTotal
                            {
                                ID = documento.F15_0_GravadoID.Trim(),
                                PayableAmount = new PayableAmount()
                                {
                                    currencyID = documento.F24_0_DocumentCurrencyCode,
                                    value = documento.F15_1_GravadoPayableAmount ?? 0
                                }
                            });
                    }
                    /* 16 - Total valor de venta - operaciones inafectas*/
                    if (!string.IsNullOrEmpty(documento.F16_0_InafectoID?.Trim()))
                    {
                        factura.UblExtensions.Extension2.ExtensionContent
                            .AdditionalInformation.AdditionalMonetaryTotals.Add(new AdditionalMonetaryTotal
                            {
                                ID = documento.F16_0_InafectoID.Trim(),
                                PayableAmount = new PayableAmount()
                                {
                                    currencyID = documento.F24_0_DocumentCurrencyCode,
                                    value = documento.F16_1_InafectoPayableAmount ?? 0
                                }
                            });
                    }
                    /* 17 - Total valor de venta - operaciones exoneradas*/
                    if (!string.IsNullOrEmpty(documento.F17_0_ExoneradasID?.Trim()))
                    {
                        factura.UblExtensions.Extension2.ExtensionContent
                            .AdditionalInformation.AdditionalMonetaryTotals.Add(new AdditionalMonetaryTotal
                            {
                                ID = documento.F17_0_ExoneradasID.Trim(),
                                PayableAmount = new PayableAmount()
                                {
                                    currencyID = documento.F24_0_DocumentCurrencyCode,
                                    value = documento.F17_1_ExoneradasPayableAmount ?? 0
                                }
                            });
                    }
                    /* 22 - Total descuentos*/
                    if (!string.IsNullOrEmpty(documento.F22_0_DiscountID?.Trim()))
                    {
                        factura.UblExtensions.Extension2.ExtensionContent
                            .AdditionalInformation.AdditionalMonetaryTotals.Add(new AdditionalMonetaryTotal
                            {
                                ID = documento.F22_0_DiscountID.Trim(),
                                PayableAmount = new PayableAmount()
                                {
                                    currencyID = documento.F24_0_DocumentCurrencyCode,
                                    value = documento.F22_1_DiscountPayableAmount ?? 0
                                }
                            });
                    }
                    /* 25 - Tipo y número de la guía de remisión relacionada con la operación
                     * TODO: /Invoice/cac:DespatchDocumentReference/cbc:ID (Número de guía)
                     * TODO: /Invoice/cac:AdditionalDocumentReference/cbc:DocumentTypeCode (Tipo de documento - Catálogo No. 12)
                     *  */

                    /* 34 - Importe de la percepción en moneda nacional
                     */
                    if (!string.IsNullOrEmpty(documento.F39_0_PercepcionID?.Trim()))
                    {
                        factura.UblExtensions.Extension2.ExtensionContent
                            .AdditionalInformation.AdditionalMonetaryTotals.Add(new AdditionalMonetaryTotal
                            {
                                ID = documento.F39_0_PercepcionID.Trim(),
                                PayableAmount = new PayableAmount()
                                {
                                    currencyID = documento.F24_0_DocumentCurrencyCode,
                                    value = documento.F39_1_ReferenceAmount ?? 0
                                },

                            });
                    }
                    /* 38 - Valor referencial del servicio de transporte de bienes realizado por vía terrestre, 
                    determinado de conformidad con lo dispuesto en el DS N°010-2006-MTC, 
                    que aprobó la Tabla de Valores Referenciales para la aplicación del Sistema al 
                    servicio de transporte de bienes realizado por vía terrestre.*/

                    /* 40 - Total Valor de Venta - Operaciones gratuitas.*/
                    if (!string.IsNullOrEmpty(documento.F40_0_GratuitasID?.Trim()))
                    {
                        factura.UblExtensions.Extension2.ExtensionContent
                            .AdditionalInformation.AdditionalMonetaryTotals.Add(new AdditionalMonetaryTotal
                            {
                                ID = documento.F40_0_GratuitasID.Trim(),
                                PayableAmount = new PayableAmount()
                                {
                                    currencyID = documento.F24_0_DocumentCurrencyCode,
                                    value = documento.F40_1_PayableAmount ?? 0
                                },

                            });
                        factura.UblExtensions.Extension2.ExtensionContent
                            .AdditionalInformation.AdditionalProperties.Add(new AdditionalProperty
                            {
                                ID = 1002,
                                Value = "Artículos gratuitos"
                            });
                    }

                    /* 26 - Leyendas */
                    if (!string.IsNullOrEmpty(documento.F26_0_AdditionalElementID1?.Trim()))
                    {
                        factura.UblExtensions.Extension2.ExtensionContent
                            .AdditionalInformation.AdditionalProperties.Add(new AdditionalProperty
                            {
                                ID = Convert.ToInt32(documento.F26_0_AdditionalElementID1),
                                Value = documento.F26_1_AdditionalElementValue1.Trim()
                            });
                    }

                    foreach (var detalleFactura in docFacturas)
                    {
                        var linea = new InvoiceLine
                        {
                            ID = Convert.ToInt32(detalleFactura.F29_0_LineID),
                            InvoicedQuantity = new InvoicedQuantity
                            {
                                unitCode = detalleFactura.F11_0_UnitInvoicedQuantity,
                                Value = detalleFactura.F12_0_InvoicedQuantity ?? 0
                            },
                            LineExtensionAmount = new PayableAmount
                            {
                                currencyID = documento.F24_0_DocumentCurrencyCode,
                                value = detalleFactura.F32_0_LineExtensionAmount ?? 0
                            },
                            AllowanceCharge = new AllowanceCharge
                            {
                                ChargeIndicator = false,
                                Amount = new PayableAmount
                                {
                                    currencyID = documento.F24_0_DocumentCurrencyCode,
                                    value = detalleFactura.F42_1_LineDiscountAmount ?? 0
                                }
                            },
                            Item = new Item
                            {
                                Description = detalleFactura.F13_0_ItemDescription.Trim(),
                                SellersItemIdentification = new SellersItemIdentification
                                {
                                    ID = detalleFactura.F30_0_SellersItemID.Trim()
                                }
                            },
                            Price = new Price
                            {
                                PriceAmount = new PayableAmount
                                {
                                    currencyID = detalleFactura.F24_0_DocumentCurrencyCode,
                                    value = detalleFactura.F31_0_UnitPriceAmount ?? 0
                                }
                            },
                            PricingReference =
                                new PricingReference
                                {
                                    AlternativeConditionPrices = new List<AlternativeConditionPrice>()
                                }
                        };

                        /* 27 - Afectación al IGV por ítem */
                        linea.TaxTotals.Add(new TaxTotal
                        {
                            TaxAmount = new PayableAmount
                            {
                                currencyID = documento.F24_0_DocumentCurrencyCode,
                                value = detalleFactura.F27_0_IGVTaxAmount ?? 0
                            },
                            TaxSubtotal = new TaxSubtotal
                            {
                                TaxAmount = new PayableAmount
                                {
                                    currencyID = documento.F24_0_DocumentCurrencyCode,
                                    value = detalleFactura.F27_1_IGVTaxSubtotalAmount ?? 0
                                },
                                TaxCategory = new TaxCategory
                                {
                                    ID = "IGV",
                                    TaxExemptionReasonCode =
                                        Convert.ToInt32(detalleFactura.F27_2_IGVTaxExemptionReasonCode),
                                    TierRange = detalleFactura.F28_2_ISCTierRange.Trim(),
                                    TaxScheme = new TaxScheme()
                                    {
                                        ID = detalleFactura.F27_3_IGVTaxSchemeID.Trim(),
                                        Name = detalleFactura.F27_4_IGVTaxSchemeName.Trim(),
                                        TaxTypeCode = detalleFactura.F27_5_IGVTaxSchemeTaxTypeCode.Trim()
                                    }
                                }
                            }
                        });

                        /* 28 - Sistema de ISC por ítem */
                        if (!string.IsNullOrEmpty(detalleFactura.F28_3_ISCTaxSchemeID))
                            linea.TaxTotals.Add(new TaxTotal
                            {
                                TaxAmount = new PayableAmount
                                {
                                    currencyID = documento.F24_0_DocumentCurrencyCode,
                                    value = detalleFactura.F28_0_ISCTaxAmount ?? 0
                                },
                                TaxSubtotal = new TaxSubtotal
                                {
                                    TaxAmount = new PayableAmount
                                    {
                                        currencyID = documento.F24_0_DocumentCurrencyCode,
                                        value = detalleFactura.F28_1_ISCTaxSubtotalAmount ?? 0
                                    },
                                    TaxCategory = new TaxCategory
                                    {
                                        ID = "ISC",
                                        TaxExemptionReasonCode =
                                            Convert.ToInt32(detalleFactura.F27_2_IGVTaxExemptionReasonCode),
                                        TierRange = detalleFactura.F28_2_ISCTierRange.Trim(),
                                        TaxScheme = new TaxScheme()
                                        {
                                            ID = detalleFactura.F28_3_ISCTaxSchemeID.Trim(),
                                            Name = detalleFactura.F28_4_ISCTaxSchemeName.Trim(),
                                            TaxTypeCode = detalleFactura.F28_5_ISCTaxSchemeTaxTypeCode.Trim()
                                        }
                                    }
                                }
                            });

                        linea.PricingReference.AlternativeConditionPrices.Add(new AlternativeConditionPrice
                        {
                            PriceAmount = new PayableAmount
                            {
                                currencyID = documento.F24_0_DocumentCurrencyCode,
                                // Comprobamos que sea una operacion gratuita.
                                value = detalleFactura.F40_1_PayableAmount.HasValue ? 0 : detalleFactura.F14_0_UnitPriceAmount ?? 0
                            },
                            PriceTypeCode = detalleFactura.F14_1_PriceTypeCode.Trim()
                        });
                        // Para operaciones no onerosas (gratuitas)
                        if (detalleFactura.F40_1_PayableAmount.HasValue)
                            linea.PricingReference.AlternativeConditionPrices.Add(new AlternativeConditionPrice
                            {
                                PriceAmount = new PayableAmount
                                {
                                    currencyID = documento.F24_0_DocumentCurrencyCode,
                                    value = detalleFactura.F14_0_UnitPriceAmount ?? 0
                                },
                                PriceTypeCode = "02"
                            });

                        // Para el caso del Valor Referencial.
                        if (detalleFactura.F33_0_AlternConditionPriceAmount.HasValue && detalleFactura.F33_1_AlternConditionPriceTypeCode == "02")
                        {
                            linea.PricingReference.AlternativeConditionPrices.Add(new AlternativeConditionPrice
                            {
                                PriceAmount = new PayableAmount
                                {
                                    currencyID = documento.F24_0_DocumentCurrencyCode,
                                    value = detalleFactura.F33_0_AlternConditionPriceAmount ?? 0
                                },
                                PriceTypeCode = detalleFactura.F33_1_AlternConditionPriceTypeCode.Trim()
                            });
                        }
                        factura.InvoiceLines.Add(linea);
                    }



                    #endregion

                    //UploadToAzureAsync(documento.F05_0_SuplierCustomerAssignedAccountID, factura, nombreArchivo).Wait();

                    // Lo enviamos a SUNAT inmediatamente.
                    //var rpt = ProcesarDocumentoEnSunat(new DTOEnvioDocumentoRequest
                    //{
                    //    NombreArchivo = nombreArchivo,
                    //    NombreBaseDatos = request.NombreBaseDatos,
                    //    RucEmisor = nombreArchivo.Substring(0, 11),
                    //});

                    response.NombreArchivo = nombreArchivo;
                    response.Respuesta.Codigo = rpt.Respuesta.Codigo;
                    response.Respuesta.Mensaje = rpt.Respuesta.Mensaje;
                }
            }
            #region Control de Excepciones
            catch (Exception ex)
            {
                response.Respuesta.Codigo = ErrorGenerico.Codigo;
                response.Respuesta.Mensaje = ErrorGenerico.Mensaje;
                response.Respuesta.MensajeTecnico = $"{ex.GetType().Name} {DesenredarException(ex)}";
                response.Respuesta.PilaLlamadas = ex.StackTrace;
                response.GrabarLog();
            }
            #endregion
            return response;
        }

    }

    public class plantilla_fedbEntities : IDisposable
    {
        public plantilla_fedbEntities(string nombreBaseDatos)
        {
            throw new NotImplementedException();
        }

        public object GP_CE_TRX_RETENCION { get; internal set; }

        public void Dispose()
        {
            throw new NotImplementedException();
        }
    }
}