﻿using ErickOrlando.FirmadoSunat.Entidades.Core;

namespace ErickOrlando.FirmadoSunat.Entidades.DTO
{
    // ReSharper disable once InconsistentNaming
    public class DTODocumentosResponse : DTOBaseResponse
    {
        public DTODocumentosResponse()
        {
            Respuesta = new ComunResponse();
        }
    }
}
