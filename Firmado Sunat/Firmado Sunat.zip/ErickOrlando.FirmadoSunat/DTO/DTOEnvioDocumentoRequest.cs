﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ErickOrlando.FirmadoSunat.Entidades.Core;

namespace ErickOrlando.FirmadoSunat.Entidades.DTO
{
    public class DTOEnvioDocumentoRequest : DTOBaseRequest
    {
        public string RucEmisor { get; set; }
        public string NombreArchivo { get; set; }
    }
}
