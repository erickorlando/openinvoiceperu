﻿using System.Collections.Generic;
using ErickOrlando.FirmadoSunat.Entidades.Core;

namespace ErickOrlando.FirmadoSunat.Entidades.DTO
{
    // ReSharper disable once InconsistentNaming
    public class DTODocumentosRequest<T> : DTOBaseRequest
    {
        public IEnumerable<T> ListaDocumentos { get; set; }

        public DTODocumentosRequest()
        {
            ListaDocumentos = new List<T>();
        }
    }
}
