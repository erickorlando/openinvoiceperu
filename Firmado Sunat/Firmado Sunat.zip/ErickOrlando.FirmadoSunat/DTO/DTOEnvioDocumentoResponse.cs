﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ErickOrlando.FirmadoSunat.Entidades.Core;

namespace ErickOrlando.FirmadoSunat.Entidades.DTO
{
    // ReSharper disable once InconsistentNaming
    public class DTOEnvioDocumentoResponse : DTOBaseResponse
    {
        public string NombreArchivo { get; set; }
    }
}
