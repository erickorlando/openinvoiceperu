﻿using System;
using System.Collections.Generic;
using System.Data.Entity.Infrastructure;
using System.Data.Entity.Validation;
using System.Linq;
using System.Text;
using ErickOrlando.Datos;
using ErickOrlando.Entidades;
using ErickOrlando.Entidades.Constantes;
using ErickOrlando.Entidades.DTO;
using ErickOrlando.Entidades.Estructuras;
using ErickOrlando.FirmadoSunat.Constantes;
using ErickOrlando.FirmadoSunat.Entidades.DTO;
using ErickOrlando.FirmadoSunat.Estructuras;

namespace ErickOrlando.FirmadoSunat
{
    public partial class ErickOrlandoService
    {
        public DTODocumentoSunatResponse GenerarTramaFactura(DTODocumentoSunatRequest request)
        {
            var response = new DTODocumentoSunatResponse();
            CambiarRegion();
            try
            {
                using (var ctx = new plantilla_fedbEntities(request.NombreBaseDatos))
                {
                    var docFacturas = from doc in ctx.GP_CE_TRX_FACTURA
                                      where doc.GP_CE_F8ID == request.IdDocumento
                                      && doc.GP_CE_F7RDRID == request.TipoDocumento
                                      orderby doc.GP_CE_F331INVLINEID
                                      select doc;

                    var documento = docFacturas.First();

                    if (documento == null)
                        throw new InvalidOperationException("No se encontró el documento");

                    var serieDocumento = documento.GP_CE_F8ID.Split('-').First();
                    var numeroDocumento = documento.GP_CE_F8ID.Split('-').Last().Trim() + request.Intento;
                    var idCompletoDocumento = string.Concat(serieDocumento, "-",
                        numeroDocumento.Substring(numeroDocumento.Length - 8));

                    var nombreArchivo = $"{documento.GP_CE_F61PARTYID}-{request.TipoDocumento}-{serieDocumento}-{numeroDocumento}";

                    #region Generacion de Factura

                    var factura = new Invoice
                    {
                        ID = idCompletoDocumento,
                        IssueDate = documento.GP_CE_F1ISSUEDATE,
                        InvoiceTypeCode = documento.GP_CE_F7RDRID.Trim(),
                        DocumentCurrencyCode = documento.GP_CE_F281DOCCURCOD,
                        Signature = new SignatureCac
                        {
                            ID = $"S{idCompletoDocumento}",
                            SignatoryParty = new SignatoryParty
                            {
                                PartyIdentification = new PartyIdentification
                                {
                                    ID = new PartyIdentificationID
                                    {
                                        value = documento.GP_CE_F61PARTYID,
                                        schemeID = documento.GP_CE_F62PARTYID
                                    }
                                },
                                PartyName = new PartyName()
                                {
                                    Name = documento.GP_CE_F3PARTYLN.Trim()
                                }
                            },
                            DigitalSignatureAttachment = new DigitalSignatureAttachment()
                            {
                                ExternalReference = new ExternalReference()
                                {
                                    URI = $"#S{idCompletoDocumento}-{documento.GP_CE_F3PARTYLN}"
                                }
                            }
                        },
                        AccountingSupplierParty = new AccountingSupplierParty
                        {
                            CustomerAssignedAccountID = documento.GP_CE_F61PARTYID,
                            AdditionalAccountID = "6",
                            Party = new Party()
                            {
                                PartyName = new PartyName()
                                {
                                    Name = documento.GP_CE_F4PARTYNAME.Trim(),
                                },
                                PostalAddress = new PostalAddress()
                                {
                                    ID = documento.GP_CE_F51POSTALADDR.Trim(),
                                    StreetName = documento.GP_CE_F52STREETNAME.Trim(),
                                    CitySubdivisionName = documento.GP_CE_F53CITYSUBDIV.Trim(),
                                    CityName = documento.GP_CE_F54CITYNAME.Trim(),
                                    CountrySubentity = documento.GP_CE_F55COUNTRYSUB.Trim(),
                                    District = documento.GP_CE_F56DISTRICT.Trim(),
                                    Country = new Country
                                    {
                                        IdentificationCode = documento.GP_CE_F57COUNTRY.Trim()
                                    }
                                },
                                PartyLegalEntity = new PartyLegalEntity
                                {
                                    RegistrationName = documento.GP_CE_F3PARTYLN.Trim()
                                }
                            }
                        },
                        AccountingCustomerParty = new AccountingSupplierParty
                        {
                            CustomerAssignedAccountID = documento.GP_CE_F91RCVRPARTYID.Trim(),
                            AdditionalAccountID = documento.GP_CE_F92RCVRPARTYID.Trim(),
                            Party = new Party
                            {
                                PartyLegalEntity = new PartyLegalEntity
                                {
                                    RegistrationName = documento.GP_CE_F10RCVRPARTYNAME.Trim(),
                                }
                            }
                        },

                        LegalMonetaryTotal = new LegalMonetaryTotal
                        {
                            AllowanceTotalAmount = new PayableAmount
                            {
                                currencyID = documento.GP_CE_F281DOCCURCOD,
                                value = documento.GP_CE_F262PAYAMNT
                            },
                            PayableAmount = new PayableAmount
                            {
                                currencyID = documento.GP_CE_F281DOCCURCOD,
                                // Si hay operaciones gratuitas el precio total es 0.
                                value = documento.GP_CE_F492PAYAMNT > 0 ? 0 : documento.GP_CE_F271PAYAMNT
                            }
                        }
                    };
                    /* 22 - Sumatoria de IGV */
                    factura.TaxTotals.Add(
                     new TaxTotal
                     {
                         TaxAmount = new PayableAmount
                         {
                             currencyID = documento.GP_CE_F281DOCCURCOD,
                             value = documento.GP_CE_F222TAXAMNT,
                         },
                         TaxSubtotal = new TaxSubtotal
                         {
                             TaxAmount = new PayableAmount
                             {
                                 currencyID = documento.GP_CE_F281DOCCURCOD,
                                 value = documento.GP_CE_F222TAXAMNT
                             },
                             TaxCategory = new TaxCategory
                             {
                                 TaxScheme = new TaxScheme
                                 {
                                     ID = documento.GP_CE_F223TAXSCHID.Trim(),
                                     Name = documento.GP_CE_F224TAXSCHNAME.Trim(),
                                     TaxTypeCode = documento.GP_CE_F225TTCODE.Trim()
                                 }
                             }
                         }
                     });
                    /* 23 - Sumatoria de ISC */
                    if (documento.GP_CE_F232TAXAMNT > 0)
                        factura.TaxTotals.Add(
                         new TaxTotal
                         {
                             TaxAmount = new PayableAmount
                             {
                                 currencyID = documento.GP_CE_F281DOCCURCOD,
                                 value = documento.GP_CE_F232TAXAMNT,
                             },
                             TaxSubtotal = new TaxSubtotal
                             {
                                 TaxAmount = new PayableAmount
                                 {
                                     currencyID = documento.GP_CE_F281DOCCURCOD,
                                     value = documento.GP_CE_F232TAXAMNT
                                 },
                                 TaxCategory = new TaxCategory
                                 {
                                     TaxScheme = new TaxScheme
                                     {
                                         ID = documento.GP_CE_F223TAXSCHID.Trim(),
                                         Name = documento.GP_CE_F236TAXSCHNAME.Trim(),
                                         TaxTypeCode = documento.GP_CE_F237TTCODE.Trim()
                                     }
                                 }
                             }
                         });
                    /* 24 - Sumatoria de otros tributos */
                    if (documento.GP_CE_F242TAXAMNT > 0)
                        factura.TaxTotals.Add(
                         new TaxTotal
                         {
                             TaxAmount = new PayableAmount
                             {
                                 currencyID = documento.GP_CE_F281DOCCURCOD,
                                 value = documento.GP_CE_F242TAXAMNT,
                             },
                             TaxSubtotal = new TaxSubtotal
                             {
                                 TaxAmount = new PayableAmount
                                 {
                                     currencyID = documento.GP_CE_F281DOCCURCOD,
                                     value = documento.GP_CE_F242TAXAMNT
                                 },
                                 TaxCategory = new TaxCategory
                                 {
                                     TaxScheme = new TaxScheme
                                     {
                                         ID = documento.GP_CE_F245TAXSCHID.Trim(),
                                         Name = documento.GP_CE_F246TAXSCHNAME.Trim(),
                                         TaxTypeCode = documento.GP_CE_F247TTCODE.Trim()
                                     }
                                 }
                             }
                         });

                    /* Tipo de Operación - Catalogo N° 17 */
                    if (!string.IsNullOrEmpty(documento.GP_CE_F2SIGN))
                    {
                        factura.UblExtensions.Extension2.ExtensionContent
                            .AdditionalInformation.SunatTransaction.Id = documento.GP_CE_F2SIGN.Trim();
                    }

                    /* 18 - Total valor de venta - operaciones gravadas */
                    if (!string.IsNullOrEmpty(documento.GP_CE_F181TAXID.Trim()))
                    {
                        factura.UblExtensions.Extension2.ExtensionContent
                            .AdditionalInformation.AdditionalMonetaryTotals.Add(new AdditionalMonetaryTotal
                            {
                                ID = documento.GP_CE_F181TAXID.Trim(),
                                PayableAmount = new PayableAmount()
                                {
                                    currencyID = documento.GP_CE_F281DOCCURCOD,
                                    value = documento.GP_CE_F183PAIDAMNT
                                }
                            });
                    }
                    /* 19 - Total valor de venta - operaciones inafectas*/
                    if (!string.IsNullOrEmpty(documento.GP_CE_F191TAXID.Trim()))
                    {
                        factura.UblExtensions.Extension2.ExtensionContent
                            .AdditionalInformation.AdditionalMonetaryTotals.Add(new AdditionalMonetaryTotal
                            {
                                ID = documento.GP_CE_F191TAXID.Trim(),
                                PayableAmount = new PayableAmount()
                                {
                                    currencyID = documento.GP_CE_F281DOCCURCOD,
                                    value = documento.GP_CE_F193PAIDAMNT
                                }
                            });
                    }
                    /* 20 - Total valor de venta - operaciones exoneradas*/
                    if (!string.IsNullOrEmpty(documento.GP_CE_F201TAXID.Trim()))
                    {
                        factura.UblExtensions.Extension2.ExtensionContent
                            .AdditionalInformation.AdditionalMonetaryTotals.Add(new AdditionalMonetaryTotal
                            {
                                ID = documento.GP_CE_F201TAXID.Trim(),
                                PayableAmount = new PayableAmount()
                                {
                                    currencyID = documento.GP_CE_F281DOCCURCOD,
                                    value = documento.GP_CE_F203PAIDAMNT
                                }
                            });
                    }
                    /* 26 - Total descuentos*/
                    if (!string.IsNullOrEmpty(documento.GP_CE_F261TAXSCHID.Trim()))
                    {
                        factura.UblExtensions.Extension2.ExtensionContent
                            .AdditionalInformation.AdditionalMonetaryTotals.Add(new AdditionalMonetaryTotal
                            {
                                ID = documento.GP_CE_F261TAXSCHID.Trim(),
                                PayableAmount = new PayableAmount()
                                {
                                    currencyID = documento.GP_CE_F281DOCCURCOD,
                                    value = documento.GP_CE_F262PAYAMNT
                                }
                            });
                    }
                    /* 32 - Importe de la percepción en moneda nacional*/
                    if (!string.IsNullOrEmpty(documento.GP_CE_F321MONTOTID.Trim()))
                    {
                        factura.UblExtensions.Extension2.ExtensionContent
                            .AdditionalInformation.AdditionalMonetaryTotals.Add(new AdditionalMonetaryTotal
                            {
                                ID = documento.GP_CE_F321MONTOTID.Trim(),
                                PayableAmount = new PayableAmount()
                                {
                                    currencyID = documento.GP_CE_F281DOCCURCOD,
                                    value = documento.GP_CE_F326PAYAMNT
                                },

                            });
                    }
                    /* 38 - Valor referencial del servicio de transporte de bienes realizado por vía terrestre, 
                    determinado de conformidad con lo dispuesto en el DS N°010-2006-MTC, 
                    que aprobó la Tabla de Valores Referenciales para la aplicación del Sistema al 
                    servicio de transporte de bienes realizado por vía terrestre.*/
                    if (!string.IsNullOrEmpty(documento.GP_CE_F381MONTOTID.Trim()))
                    {
                        factura.UblExtensions.Extension2.ExtensionContent
                            .AdditionalInformation.AdditionalMonetaryTotals.Add(new AdditionalMonetaryTotal
                            {
                                ID = documento.GP_CE_F381MONTOTID.Trim(),
                                PayableAmount = new PayableAmount()
                                {
                                    currencyID = documento.GP_CE_F281DOCCURCOD,
                                    value = documento.GP_CE_F382REFAMNT
                                },
                                //Percent = documento.GP_CE_F381MONTOTID.Trim() == "2003" ? 0.10m : 0
                            });
                    }

                    /* 49 - Total Valor de Venta - Operaciones gratuitas.*/
                    if (!string.IsNullOrEmpty(documento.GP_CE_F491PROPID.Trim()))
                    {
                        factura.UblExtensions.Extension2.ExtensionContent
                            .AdditionalInformation.AdditionalMonetaryTotals.Add(new AdditionalMonetaryTotal
                            {
                                ID = documento.GP_CE_F491PROPID.Trim(),
                                PayableAmount = new PayableAmount()
                                {
                                    currencyID = documento.GP_CE_F281DOCCURCOD,
                                    value = documento.GP_CE_F492PAYAMNT
                                },

                            });
                        factura.UblExtensions.Extension2.ExtensionContent
                            .AdditionalInformation.AdditionalProperties.Add(new AdditionalProperty
                            {
                                ID = 1002,
                                Value = "Artículos gratuitos"
                            });
                    }

                    /* 31 - Leyendas */
                    if (!string.IsNullOrEmpty(documento.GP_CE_F311PROPID.Trim()))
                    {
                        factura.UblExtensions.Extension2.ExtensionContent
                            .AdditionalInformation.AdditionalProperties.Add(new AdditionalProperty
                            {
                                ID = Convert.ToInt32(documento.GP_CE_F311PROPID),
                                Value = documento.GP_CE_F312PROPVALUE.Trim()
                            });
                    }
                    /* 39 - Nombre y matrícula de la embarcación pesquera utilizada para efectuar 
                    la extracción y descarga de los bienes vendidos, en los casos que 
                    se hubiera utilizado dicho medio */
                    if (!string.IsNullOrEmpty(documento.GP_CE_F391PROPID.Trim()))
                    {
                        factura.UblExtensions.Extension2.ExtensionContent
                            .AdditionalInformation.AdditionalProperties.Add(new AdditionalProperty
                            {
                                ID = Convert.ToInt32(documento.GP_CE_F391PROPID),
                                Value = documento.GP_CE_F392PROPVALUE.Trim()
                            });
                    }
                    /* 40 - Descripción del tipo y cantidad de la especie vendida */
                    if (!string.IsNullOrEmpty(documento.GP_CE_F401PROPID.Trim()))
                    {
                        factura.UblExtensions.Extension2.ExtensionContent
                            .AdditionalInformation.AdditionalProperties.Add(new AdditionalProperty
                            {
                                ID = Convert.ToInt32(documento.GP_CE_F401PROPID),
                                Value = documento.GP_CE_F402PROPVALUE.Trim()
                            });
                    }
                    /* 41 - Lugar de la descarga */
                    if (!string.IsNullOrEmpty(documento.GP_CE_F411PROPID.Trim()))
                    {
                        factura.UblExtensions.Extension2.ExtensionContent
                            .AdditionalInformation.AdditionalProperties.Add(new AdditionalProperty
                            {
                                ID = Convert.ToInt32(documento.GP_CE_F411PROPID),
                                Value = documento.GP_CE_F412PROPVALUE.Trim()
                            });
                    }
                    /* 42 - Fecha de la descarga */
                    if (!string.IsNullOrEmpty(documento.GP_CE_F421PROPID.Trim()))
                    {
                        factura.UblExtensions.Extension2.ExtensionContent
                            .AdditionalInformation.AdditionalProperties.Add(new AdditionalProperty
                            {
                                ID = Convert.ToInt32(documento.GP_CE_F421PROPID),
                                Value = documento.GP_CE_F422PROPVALUE.Trim()
                            });
                    }
                    /* 43 - Numero de registro MTC */
                    if (!string.IsNullOrEmpty(documento.GP_CE_F431PROPID.Trim()))
                    {
                        factura.UblExtensions.Extension2.ExtensionContent
                            .AdditionalInformation.AdditionalProperties.Add(new AdditionalProperty
                            {
                                ID = Convert.ToInt32(documento.GP_CE_F431PROPID),
                                Value = documento.GP_CE_F432PROPVALUE.Trim()
                            });
                    }
                    /* 44 - Configuracion vehicular */
                    if (!string.IsNullOrEmpty(documento.GP_CE_F441PROPID.Trim()))
                    {
                        factura.UblExtensions.Extension2.ExtensionContent
                            .AdditionalInformation.AdditionalProperties.Add(new AdditionalProperty
                            {
                                ID = Convert.ToInt32(documento.GP_CE_F441PROPID),
                                Value = documento.GP_CE_F442PROPVALUE.Trim()
                            });
                    }
                    /* 45 - Punto de origen */
                    if (!string.IsNullOrEmpty(documento.GP_CE_F451PROPID.Trim()))
                    {
                        factura.UblExtensions.Extension2.ExtensionContent
                            .AdditionalInformation.AdditionalProperties.Add(new AdditionalProperty
                            {
                                ID = Convert.ToInt32(documento.GP_CE_F451PROPID),
                                Value = documento.GP_CE_F452PROPVALUE.Trim()
                            });
                    }
                    /* 46 - Punto de destino */
                    if (!string.IsNullOrEmpty(documento.GP_CE_F461PROPID.Trim()))
                    {
                        factura.UblExtensions.Extension2.ExtensionContent
                            .AdditionalInformation.AdditionalProperties.Add(new AdditionalProperty
                            {
                                ID = Convert.ToInt32(documento.GP_CE_F461PROPID),
                                Value = documento.GP_CE_F462PROPVALUE.Trim()
                            });
                    }
                    /* 47 - Valor referencial preliminar */
                    if (!string.IsNullOrEmpty(documento.GP_CE_F471PROPID.Trim()))
                    {
                        factura.UblExtensions.Extension2.ExtensionContent
                            .AdditionalInformation.AdditionalProperties.Add(new AdditionalProperty
                            {
                                ID = Convert.ToInt32(documento.GP_CE_F471PROPID),
                                Name = documento.GP_CE_F472PROPNAME.Trim(),
                                Value = documento.GP_CE_F473PROPVALUE.Trim()
                            });
                    }
                    /* 48 - Fecha de consumo */
                    if (!string.IsNullOrEmpty(documento.GP_CE_F481PROPID.Trim()))
                    {
                        factura.UblExtensions.Extension2.ExtensionContent
                            .AdditionalInformation.AdditionalProperties.Add(new AdditionalProperty
                            {
                                ID = Convert.ToInt32(documento.GP_CE_F481PROPID),
                                Value = documento.GP_CE_F482PROPVALUE.Trim()
                            });
                    }

                    foreach (var detalleFactura in docFacturas)
                    {
                        var linea = new InvoiceLine
                        {
                            ID = Convert.ToInt32(detalleFactura.GP_CE_F331INVLINEID),
                            InvoicedQuantity = new InvoicedQuantity
                            {
                                unitCode = detalleFactura.GP_CE_F11UOFM,
                                Value = detalleFactura.GP_CE_F12QTY
                            },
                            LineExtensionAmount = new PayableAmount
                            {
                                currencyID = documento.GP_CE_F281DOCCURCOD,
                                value = detalleFactura.GP_CE_F212LINEAMNT
                            },
                            AllowanceCharge = new AllowanceCharge
                            {
                                ChargeIndicator = false,
                                Amount = new PayableAmount
                                {
                                    currencyID = documento.GP_CE_F281DOCCURCOD,
                                    value = detalleFactura.GP_CE_F512AMNT
                                }
                            },
                            Item = new Item
                            {
                                Description = detalleFactura.GP_CE_F13ITEMDESC.Trim(),
                                SellersItemIdentification = new SellersItemIdentification
                                {
                                    ID = detalleFactura.GP_CE_F341ITEMID.Trim()
                                }
                            },
                            Price = new Price
                            {
                                PriceAmount = new PayableAmount
                                {
                                    currencyID = detalleFactura.GP_CE_F142CURID,
                                    value = detalleFactura.GP_CE_F141UNITPRICE
                                }
                            },
                            PricingReference =
                                new PricingReference
                                {
                                    AlternativeConditionPrices = new List<AlternativeConditionPrice>()
                                }
                        };

                        /* 16 - Afectación al IGV por ítem */
                        linea.TaxTotals.Add(new TaxTotal
                        {
                            TaxAmount = new PayableAmount
                            {
                                currencyID = documento.GP_CE_F281DOCCURCOD,
                                value = detalleFactura.GP_CE_F161TAXAMNT
                            },
                            TaxSubtotal = new TaxSubtotal
                            {
                                TaxAmount = new PayableAmount
                                {
                                    currencyID = documento.GP_CE_F281DOCCURCOD,
                                    value = detalleFactura.GP_CE_F161TAXAMNT
                                },
                                TaxCategory = new TaxCategory
                                {
                                    ID = "IGV",
                                    TaxExemptionReasonCode = Convert.ToInt32(detalleFactura.GP_CE_F165TAXERC),
                                    TierRange = detalleFactura.GP_CE_F175TAXTR.Trim(),
                                    TaxScheme = new TaxScheme()
                                    {
                                        ID = detalleFactura.GP_CE_F166TAXSCHID.Trim(),
                                        Name = detalleFactura.GP_CE_F167TAXSCHNAME.Trim(),
                                        TaxTypeCode = detalleFactura.GP_CE_F168TTCODE.Trim()
                                    }
                                }
                            }
                        });

                        /* 17 - Sistema de ISC por ítem */
                        if (detalleFactura.GP_CE_F172TAXAMNT > 0)
                            linea.TaxTotals.Add(new TaxTotal
                            {
                                TaxAmount = new PayableAmount
                                {
                                    currencyID = documento.GP_CE_F281DOCCURCOD,
                                    value = detalleFactura.GP_CE_F172TAXAMNT
                                },
                                TaxSubtotal = new TaxSubtotal
                                {
                                    TaxAmount = new PayableAmount
                                    {
                                        currencyID = documento.GP_CE_F281DOCCURCOD,
                                        value = detalleFactura.GP_CE_F172TAXAMNT
                                    },
                                    TaxCategory = new TaxCategory
                                    {
                                        ID = "ISC",
                                        TaxExemptionReasonCode = Convert.ToInt32(detalleFactura.GP_CE_F165TAXERC),
                                        TierRange = detalleFactura.GP_CE_F175TAXTR.Trim(),
                                        TaxScheme = new TaxScheme()
                                        {
                                            ID = detalleFactura.GP_CE_F176TAXSCHID.Trim(),
                                            Name = detalleFactura.GP_CE_F177TAXSCHNAME.Trim(),
                                            TaxTypeCode = detalleFactura.GP_CE_F178TTCODE.Trim()
                                        }
                                    }
                                }
                            });

                        linea.PricingReference.AlternativeConditionPrices.Add(new AlternativeConditionPrice
                        {
                            PriceAmount = new PayableAmount
                            {
                                currencyID = documento.GP_CE_F281DOCCURCOD,
                                // Comprobamos que sea una operacion gratuita.
                                value = detalleFactura.GP_CE_F492PAYAMNT > 0 ? 0 : detalleFactura.GP_CE_F151PRICEAMNT
                            },
                            PriceTypeCode = detalleFactura.GP_CE_F152PTCODE.Trim()
                        });
                        // Para operaciones no onerosas (gratuitas)
                        if (detalleFactura.GP_CE_F492PAYAMNT > 0)
                            linea.PricingReference.AlternativeConditionPrices.Add(new AlternativeConditionPrice
                            {
                                PriceAmount = new PayableAmount
                                {
                                    currencyID = documento.GP_CE_F281DOCCURCOD,
                                    value = detalleFactura.GP_CE_F151PRICEAMNT
                                },
                                PriceTypeCode = "02"
                            });

                        // Para el caso del Valor Referencial.
                        if (detalleFactura.GP_CE_F351PRICEAMNT > 0 && detalleFactura.GP_CE_F353PTCODE == "02")
                        {
                            linea.PricingReference.AlternativeConditionPrices.Add(new AlternativeConditionPrice
                            {
                                PriceAmount = new PayableAmount
                                {
                                    currencyID = documento.GP_CE_F281DOCCURCOD,
                                    value = detalleFactura.GP_CE_F351PRICEAMNT
                                },
                                PriceTypeCode = detalleFactura.GP_CE_F353PTCODE.Trim()
                            });
                        }
                        factura.InvoiceLines.Add(linea);
                    }



                    #endregion

                    //UploadToAzureAsync(documento.GP_CE_F61PARTYID, factura, nombreArchivo).Wait();

                    // Lo enviamos a SUNAT inmediatamente.
                    //var rpt = ProcesarDocumentoEnSunat(new DTOEnvioDocumentoRequest
                    //{
                    //    NombreArchivo = nombreArchivo,
                    //    NombreBaseDatos = request.NombreBaseDatos,
                    //    RucEmisor = nombreArchivo.Substring(0, 11),
                    //});

                    response.NombreArchivo = nombreArchivo;
                    //response.Respuesta.Codigo = rpt.Respuesta.Codigo;
                    //response.Respuesta.Mensaje = rpt.Respuesta.Mensaje;
                }
            }
            #region Control de Excepciones
            catch (Exception ex)
            {
                response.Respuesta.Codigo = ErrorGenerico.Codigo;
                response.Respuesta.Mensaje = ErrorGenerico.Mensaje;
                response.Respuesta.MensajeTecnico = $"{ex.GetType().Name} {DesenredarException(ex)}";
                response.Respuesta.PilaLlamadas = ex.StackTrace;
                response.GrabarLog();
            }
            #endregion
            return response;
        }

    }
}