﻿using System;
using System.Collections.Generic;
using ErickOrlando.Entidades.Constantes;
using ErickOrlando.Entidades.DTO;
using ErickOrlando.Entidades.Estructuras;
using ErickOrlando.Generador;

namespace ErickOrlando.FirmadoSunat
{
    public partial class ErickOrlandoService
    {
        public DTODocumentoSunatResponse GenerarTramaComunicacionBaja(DTODocumentoSunatRequest request)
        {
            var response = new DTODocumentoSunatResponse();
            try
            {
                var ruc = "20549202960";

                var nombreArchivo = $"{ruc}-RA-{request.IdDocumento}-{request.Intento}";
                var motivoBaja = "ANULACIÓN DE LA FACTURA";

                #region Generacion de Comunicacion de Baja
                var comunicacionBaja = new VoidedDocuments
                {
                    IssueDate = DateTime.Now,
                    ReferenceDate = DateTime.Today,
                    ID = $"RA-{request.IdDocumento}-{request.Intento}",
                    Signature = new SignatureCac
                    {
                        ID = "IDSignIB2B",
                        SignatoryParty = new SignatoryParty
                        {
                            PartyIdentification = new PartyIdentification
                            {
                                ID = new PartyIdentificationID
                                {
                                    value = ruc
                                }
                            },
                            PartyName = new PartyName
                            {
                                Name = "DEMO FELECTRONICA"
                            }
                        },
                        DigitalSignatureAttachment = new DigitalSignatureAttachment
                        {
                            ExternalReference = new ExternalReference
                            {
                                URI = $"#IDSignIB2B"
                            }
                        }
                    },
                    AccountingSupplierParty = new AccountingSupplierParty
                    {
                        CustomerAssignedAccountID = ruc,
                        AdditionalAccountID = "6",
                        Party = new Party
                        {
                            PartyLegalEntity = new PartyLegalEntity
                            {
                                RegistrationName = "DEMO FELECTRONICA"
                            }
                        }
                    },
                    VoidedDocumentsLines = new List<VoidedDocumentsLine>
                    {
                        new VoidedDocumentsLine
                        {
                            LineID = 1,
                            DocumentTypeCode = "01",
                            DocumentSerialID = "FF01",
                            DocumentNumberID = 12,
                            VoidReasonDescription = $"{motivoBaja} 1"
                        },
                        new VoidedDocumentsLine
                        {
                            LineID = 2,
                            DocumentTypeCode = "01",
                            DocumentSerialID = "FF01",
                            DocumentNumberID = 22,
                            VoidReasonDescription = $"{motivoBaja} 2"
                        },
                        new VoidedDocumentsLine
                        {
                            LineID = 3,
                            DocumentTypeCode = "01",
                            DocumentSerialID = "FF01",
                            DocumentNumberID = 33,
                            VoidReasonDescription = $"{motivoBaja} 3"
                        },
                        new VoidedDocumentsLine
                        {
                            LineID = 4,
                            DocumentTypeCode = "01",
                            DocumentSerialID = "FF01",
                            DocumentNumberID = 41,
                            VoidReasonDescription = $"{motivoBaja} 4"
                        },
                        new VoidedDocumentsLine
                        {
                            LineID = 5,
                            DocumentTypeCode = "01",
                            DocumentSerialID = "FF01",
                            DocumentNumberID = 50,
                            VoidReasonDescription = $"{motivoBaja} 5"
                        }
                    }
                };


                #endregion

                UploadToAzureAsync(ruc, comunicacionBaja, nombreArchivo).Wait();

                // Obtenemos una tupla con el usuario y password de la clave SOL SUNAT.
                var datosSol = ObtenerDatosSol(ruc);

                using (var conexion = new Connect(ruc, datosSol.Item1, datosSol.Item2))
                {
                    var tramaZip = DownloadFromAzureAsync(nombreArchivo).Result;

                    var resultado = conexion.EnviarResumenBaja(tramaZip, string.Concat(nombreArchivo, ".zip"));

                    if (resultado.Item2)
                    {
                        response.Respuesta.Codigo = MensajeExitoso.Codigo;
                        response.Respuesta.Mensaje = $"{EnvioSunatCorrecto} con el Ticket # {resultado.Item1}";
                    }
                    else
                    {
                        response.Respuesta.Codigo = ErrorSUNAT.Codigo;
                        response.Respuesta.Mensaje = $"{ErrorSUNAT.Mensaje} {resultado.Item1}";
                    }

                }


            }
            catch (Exception ex)
            {
                response.Respuesta.Codigo = ErrorGenerico.Codigo;
                response.Respuesta.Mensaje = ErrorGenerico.Mensaje;
                response.Respuesta.MensajeTecnico = $"{ex.GetType().Name} {DesenredarException(ex)}";
                response.Respuesta.PilaLlamadas = ex.StackTrace;
                response.GrabarLog();
            }
            return response;
        }

        public DTOEnvioDocumentoResponse ConsultarTicketSunat(DTOEnvioDocumentoRequest request)
        {
            var response = new DTOEnvioDocumentoResponse();
            try
            {

                // Obtenemos una tupla con el usuario y password de la clave SOL SUNAT.
                var datosSol = ObtenerDatosSol(request.RucEmisor);

                using (var conexion = new Connect(request.RucEmisor, datosSol.Item1, datosSol.Item2))
                {
                    var resultado = conexion.ObtenerEstado(request.NombreArchivo);

                    if (resultado.Item2)
                    {
                        var archivo = $"{request.RucEmisor}-{request.NombreArchivo}";
                        UploadToAzureAsync(archivo, Convert.FromBase64String(resultado.Item1));

                        response.Respuesta.Codigo = MensajeExitoso.Codigo;
                        response.Respuesta.Mensaje = EnvioSunatCorrecto;
                        response.NombreArchivo = archivo;
                    }
                    else
                    {
                        response.Respuesta.Codigo = ErrorSUNAT.Codigo;
                        response.Respuesta.Mensaje = $"{ErrorSUNAT.Mensaje} {resultado.Item1}";
                    }
                }

            }
            catch (Exception ex)
            {
                response.Respuesta.Codigo = ErrorGenerico.Codigo;
                response.Respuesta.Mensaje = ErrorGenerico.Mensaje;
                response.Respuesta.MensajeTecnico = $"{ex.GetType().Name} {DesenredarException(ex)}";
                response.Respuesta.PilaLlamadas = ex.StackTrace;
                response.GrabarLog();
            }
            return response;
        }

    }
}