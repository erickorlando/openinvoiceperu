﻿using System;
using System.Globalization;
using System.IO;
using System.Text;
using System.Threading.Tasks;

namespace ErickOrlando.FirmadoSunat
{

    public partial class ErickOrlandoService
    {
        private const string EnvioSunatCorrecto = "Proceso de SUNAT enviado correctamente";
        private const string NoSeRegistraronDatos = "No se pudieron registrar los documentos";

        #region Metodos Privados
        private string DesenredarException(Exception ex)
        {
            var sb = new StringBuilder();
            sb.AppendLine(ex.Message);
            AgregarInner(ex, sb);

            var cadena = sb.ToString();
            sb.Length = 0;

            return cadena;
        }

        private static void AgregarInner(Exception ex, StringBuilder sb)
        {
            if (ex.InnerException != null)
            {
                sb.AppendLine(ex.InnerException.ToString());
                if (ex.InnerException.InnerException != null)
                {
                    AgregarInner(ex.InnerException.InnerException, sb);
                }
            }
        }

        private string QuitarLetras(string valor)
        {
            var sb = new StringBuilder();

            foreach (var caracter in valor)
            {
                if (char.IsDigit(caracter))
                    sb.Append(caracter);
            }

            var resultado = sb.ToString();
            sb.Length = 0;
            return resultado;
        }

        private void CambiarRegion()
        {
            System.Threading.Thread.CurrentThread.CurrentCulture = new CultureInfo("es-PE");
            System.Threading.Thread.CurrentThread.CurrentUICulture = new CultureInfo("es-PE");
        }

        #endregion

        private string DownloadFromAzureAsync(string nombreArchivo)
        {
            throw new NotImplementedException();
        }
    }
}
