﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ErickOrlando.Entidades
{
    public partial class GP_CE_TRX_FACTURA
    {

        public override string ToString()
        {
            return DEX_ROW_ID.ToString();
        }
    }
}
