﻿using System;
using System.Collections.Generic;
using System.Data.Entity.Infrastructure;
using System.Data.Entity.Validation;
using System.Linq;
using System.Text;
using ErickOrlando.Datos;
using ErickOrlando.Entidades;
using ErickOrlando.Entidades.Constantes;
using ErickOrlando.Entidades.DTO;
using ErickOrlando.Entidades.Estructuras;
using ErickOrlando.FirmadoSunat.Constantes;
using ErickOrlando.FirmadoSunat.Entidades.DTO;
using ErickOrlando.FirmadoSunat.Estructuras;
using ErickOrlando.Generador;

namespace ErickOrlando.FirmadoSunat
{
    public partial class ErickOrlandoService
    {


        public DTODocumentoSunatResponse GenerarTramaNotaCredito(DTODocumentoSunatRequest request)
        {
            var response = new DTODocumentoSunatResponse();
            try
            {
                CambiarRegion();
                using (var ctx = new plantilla_fedbEntities(request.NombreBaseDatos))
                {
                    var docNotasCredito = (from doc in ctx.IB2B_PFE_NotaCredito
                                           where doc.F08_0_SerieCorrelativo == request.IdDocumento
                                           select doc).ToList();

                    var documento = docNotasCredito.First();

                    if (documento == null)
                        throw new InvalidOperationException("No se encontró el documento");

                    var serieDocumento = documento.F08_0_SerieCorrelativo.Split('-').First();
                    // Nos aseguramos que la serie tenga 4 digitos.
                    if (serieDocumento.Length < 4)
                        serieDocumento = serieDocumento.PadLeft(4, 'F');
                    var numeroDocumento = documento.F08_0_SerieCorrelativo.Split('-').Last().Trim() + request.Intento;
                    // Nos aseguramos que el numero de documento no exceda los 8 caracteres.
                    if (numeroDocumento.Length > 8)
                        numeroDocumento = numeroDocumento.Substring(numeroDocumento.Length - 8);
                    var idCompletoDocumento = string.Concat(serieDocumento, "-", numeroDocumento);

                    var nombreArchivo = $"{documento.F06_0_SuplierCustomerAssignedAccountID}-07-{serieDocumento}-{numeroDocumento}";

                    #region Generacion de Nota de Credito

                    #region Cabecera
                    var notaCredito = new CreditNote
                    {
                        ID = idCompletoDocumento,
                        IssueDate = documento.F01_0_IssueDate ?? DateTime.Now,
                        DocumentCurrencyCode = documento.F30_0_DocumentCurrencyCode,
                        Signature = new SignatureCac
                        {
                            ID = $"S{idCompletoDocumento}",
                            SignatoryParty = new SignatoryParty
                            {
                                PartyIdentification = new PartyIdentification
                                {
                                    ID = new PartyIdentificationID
                                    {
                                        value = documento.F06_0_SuplierCustomerAssignedAccountID,
                                        schemeID = documento.F06_1_SuplierAdditionalAccountID
                                    }
                                },
                                PartyName = new PartyName()
                                {
                                    Name = documento.F03_0_SuplierRegistrationName.Trim()
                                }
                            },
                            DigitalSignatureAttachment = new DigitalSignatureAttachment()
                            {
                                ExternalReference = new ExternalReference()
                                {
                                    URI = $"#S{idCompletoDocumento}-{documento.F03_0_SuplierRegistrationName}"
                                }
                            }
                        },
                        AccountingSupplierParty = new AccountingSupplierParty
                        {
                            CustomerAssignedAccountID = documento.F06_0_SuplierCustomerAssignedAccountID,
                            AdditionalAccountID = "6",
                            Party = new Party()
                            {
                                PartyName = new PartyName()
                                {
                                    Name = documento.F04_0_SuplierName.Trim(),
                                },
                                PostalAddress = new PostalAddress()
                                {
                                    ID = documento.F05_0_SuplierID.Trim(),
                                    StreetName = documento.F05_1_SuplierStreetName.Trim(),
                                    CitySubdivisionName = documento.F05_2_SuplierCitySubdivisionName.Trim(),
                                    CityName = documento.F05_3_SuplierCityName.Trim(),
                                    CountrySubentity = documento.F05_4_SuplierCountrySubentity.Trim(),
                                    District = documento.F05_5_SuplierDistrict.Trim(),
                                    Country = new Country
                                    {
                                        IdentificationCode = documento.F05_6_SuplierIdentificationCode.Trim()
                                    }
                                },
                                PartyLegalEntity = new PartyLegalEntity
                                {
                                    RegistrationName = documento.F03_0_SuplierRegistrationName.Trim()
                                }
                            }
                        },
                        AccountingCustomerParty = new AccountingSupplierParty
                        {
                            CustomerAssignedAccountID = documento.F09_0_CustomerAssignedAccountID.Trim(),
                            AdditionalAccountID = documento.F09_1_CustomerAdditionalAccountID.Trim(),
                            Party = new Party
                            {
                                PartyLegalEntity = new PartyLegalEntity
                                {
                                    RegistrationName = documento.F10_0_CustomerRegistrationName.Trim(),
                                }
                            }
                        },

                        LegalMonetaryTotal = new LegalMonetaryTotal
                        {
                            ChargeTotalAmount = new PayableAmount
                            {
                                currencyID = documento.F30_0_DocumentCurrencyCode,
                                value = documento.F27_0_ChargeTotalAmount.HasValue ?
                                                    documento.F27_0_ChargeTotalAmount.Value : 0
                            },
                            PayableAmount = new PayableAmount
                            {
                                currencyID = documento.F30_0_DocumentCurrencyCode,
                                value = documento.F29_0_PayableAmount.HasValue ?
                                                    documento.F29_0_PayableAmount.Value : 0
                            }
                        }
                    };
                    #endregion

                    #region Sumatoria de Impuestos
                    /* 24 - Sumatoria de IGV */
                    notaCredito.TaxTotals.Add(
                     new TaxTotal
                     {
                         TaxAmount = new PayableAmount
                         {
                             currencyID = documento.F30_0_DocumentCurrencyCode,
                             value = documento.F24_0_IGVTaxAmountID ?? 0,
                         },
                         TaxSubtotal = new TaxSubtotal
                         {
                             TaxAmount = new PayableAmount
                             {
                                 currencyID = documento.F30_0_DocumentCurrencyCode,
                                 value = documento.F24_1_IGVTaxAmount ?? 0
                             },
                             TaxCategory = new TaxCategory
                             {
                                 TaxScheme = new TaxScheme
                                 {
                                     ID = documento.F24_2_IGVTaxSchemeID.Trim(),
                                     Name = documento.F24_3_IGVTaxSchemeName.Trim(),
                                     TaxTypeCode = documento.F24_4_IGVTaxSchemeTaxTypeCode.Trim()
                                 }
                             }
                         }
                     });
                    /* 25 - Sumatoria de ISC */
                    if (documento.F25_0_ISCTaxAmountID.HasValue)
                        notaCredito.TaxTotals.Add(
                         new TaxTotal
                         {
                             TaxAmount = new PayableAmount
                             {
                                 currencyID = documento.F30_0_DocumentCurrencyCode,
                                 value = documento.F25_0_ISCTaxAmountID.Value,
                             },
                             TaxSubtotal = new TaxSubtotal
                             {
                                 TaxAmount = new PayableAmount
                                 {
                                     currencyID = documento.F30_0_DocumentCurrencyCode,
                                     value = documento.F25_1_ISCTaxAmount ?? 0
                                 },
                                 TaxCategory = new TaxCategory
                                 {
                                     TaxScheme = new TaxScheme
                                     {
                                         ID = documento.F25_2_ISCTaxSchemeID.Trim(),
                                         Name = documento.F25_3_ISCTaxSchemeName.Trim(),
                                         TaxTypeCode = documento.F25_4_ISCTaxSchemeTaxTypeCode.Trim()
                                     }
                                 }
                             }
                         });
                    /* 26 - Sumatoria de otros tributos */
                    if (documento.F26_0_OtherTaxAmountID.HasValue)
                        notaCredito.TaxTotals.Add(
                         new TaxTotal
                         {
                             TaxAmount = new PayableAmount
                             {
                                 currencyID = documento.F30_0_DocumentCurrencyCode,
                                 value = documento.F26_0_OtherTaxAmountID.Value,
                             },
                             TaxSubtotal = new TaxSubtotal
                             {
                                 TaxAmount = new PayableAmount
                                 {
                                     currencyID = documento.F30_0_DocumentCurrencyCode,
                                     value = documento.F26_1_OtherTaxAmount ?? 0
                                 },
                                 TaxCategory = new TaxCategory
                                 {
                                     TaxScheme = new TaxScheme
                                     {
                                         ID = documento.F26_2_OtherTaxSchemeID.Trim(),
                                         Name = documento.F26_3_OtherTaxSchemeName.Trim(),
                                         TaxTypeCode = documento.F26_4_OtherTaxSchemeTaxTypeCode.Trim()
                                     }
                                 }
                             }
                         });
                    #endregion

                    #region Totales
                    /* 20 - Total valor de venta - operaciones gravadas */
                    if (!string.IsNullOrEmpty(documento.F20_0_GravadoID))
                    {
                        notaCredito.UBLExtensions.Extension2.ExtensionContent
                            .AdditionalInformation.AdditionalMonetaryTotals.Add(new AdditionalMonetaryTotal
                            {
                                ID = documento.F20_0_GravadoID.Trim(),
                                PayableAmount = new PayableAmount()
                                {
                                    currencyID = documento.F30_0_DocumentCurrencyCode,
                                    value = documento.F20_1_GravadoPayableAmount ?? 0
                                }
                            });
                    }
                    /* 21 - Total valor de venta - operaciones inafectas*/
                    if (!string.IsNullOrEmpty(documento.F21_0_InafectoID))
                    {
                        notaCredito.UBLExtensions.Extension2.ExtensionContent
                            .AdditionalInformation.AdditionalMonetaryTotals.Add(new AdditionalMonetaryTotal
                            {
                                ID = documento.F21_0_InafectoID.Trim(),
                                PayableAmount = new PayableAmount()
                                {
                                    currencyID = documento.F30_0_DocumentCurrencyCode,
                                    value = documento.F21_1_InafectoPayableAmount ?? 0
                                }
                            });
                    }
                    /* 22 - Total valor de venta - operaciones exoneradas*/
                    if (!string.IsNullOrEmpty(documento.F22_0_ExoneradasID))
                    {
                        notaCredito.UBLExtensions.Extension2.ExtensionContent
                            .AdditionalInformation.AdditionalMonetaryTotals.Add(new AdditionalMonetaryTotal
                            {
                                ID = documento.F22_0_ExoneradasID.Trim(),
                                PayableAmount = new PayableAmount()
                                {
                                    currencyID = documento.F30_0_DocumentCurrencyCode,
                                    value = documento.F22_1_ExoneradasPayableAmount ?? 0
                                }
                            });
                    }
                    /* 28 - Total descuentos*/
                    if (!string.IsNullOrEmpty(documento.F28_0_DiscountID))
                    {
                        notaCredito.UBLExtensions.Extension2.ExtensionContent
                            .AdditionalInformation.AdditionalMonetaryTotals.Add(new AdditionalMonetaryTotal
                            {
                                ID = documento.F28_0_DiscountID.Trim(),
                                PayableAmount = new PayableAmount()
                                {
                                    currencyID = documento.F30_0_DocumentCurrencyCode,
                                    value = documento.F28_1_DiscountPayableAmount ?? 0
                                }
                            });
                    }
                    #endregion

                    #region Datos propios de la NC
                    foreach (var item in docNotasCredito.Distinct(new ComparadorNotaCredito()))
                    {
                        /* 7 - Código del tipo de Nota de crédito electrónica */

                        var discrepancy = new DiscrepancyResponse
                        {
                            ReferenceID = item.F07_0_ReferenceID,
                            ResponseCode = item.F07_1_ResponseCode,
                            Description = item.F11_0_DiscrepancyResponseDescription
                        };
                        if (!notaCredito.DiscrepancyResponses.Contains(discrepancy))
                            notaCredito.DiscrepancyResponses.Add(discrepancy);

                        /* 31 - Serie y número del documento que modifica */
                        var billing = new BillingReference
                        {
                            InvoiceDocumentReference = new InvoiceDocumentReference
                            {
                                ID = item.F31_0_ReferenceSerieCorrelativo,
                                DocumentTypeCode = item.F32_0_ReferenceDocumentTypeCode
                            }
                        };
                        if (!notaCredito.BillingReferences.Contains(billing))
                            notaCredito.BillingReferences.Add(billing);

                        /* 33 - Documento de referencia */
                        if (!string.IsNullOrEmpty(item.F33_0_GRSerieCorrelativo))
                            notaCredito.DespatchDocumentReferences.Add(new InvoiceDocumentReference
                            {
                                ID = item.F33_0_GRSerieCorrelativo,
                                DocumentTypeCode = item.F33_1_GRDocumentTypeCode
                            });
                        if (!string.IsNullOrEmpty(item.F33_2_ORID))
                        {
                            notaCredito.AdditionalDocumentReferences.Add(new InvoiceDocumentReference
                            {
                                ID = item.F33_2_ORID,
                                DocumentTypeCode = item.F33_3_ORDocRefDocumentTypeCode
                            });
                        }
                    }
                    #endregion

                    #region Detalles de la NC
                    foreach (var detalleFactura in docNotasCredito)
                    {
                        var linea = new InvoiceLine
                        {
                            ID = Convert.ToInt32(detalleFactura.F34_0_LineID),
                            CreditedQuantity = new InvoicedQuantity
                            {
                                unitCode = detalleFactura.F12_0_UnitCreditedQuantity,
                                Value = detalleFactura.F13_0_CreditedQuantity.Value
                            },
                            LineExtensionAmount = new PayableAmount
                            {
                                currencyID = documento.F30_0_DocumentCurrencyCode,
                                value = detalleFactura.F23_0_LineExtensionAmount.Value
                            },
                            Item = new Item
                            {
                                Description = detalleFactura.F15_0_ItemDescription.Trim(),
                                SellersItemIdentification = new SellersItemIdentification
                                {
                                    ID = detalleFactura.F14_0_ItemID.Trim()
                                }
                            },
                            Price = new Price
                            {
                                PriceAmount = new PayableAmount
                                {
                                    currencyID = detalleFactura.F30_0_DocumentCurrencyCode,
                                    value = detalleFactura.F16_0_UnitPriceAmount.Value
                                }
                            },
                            PricingReference =
                                new PricingReference
                                {
                                    AlternativeConditionPrices = new List<AlternativeConditionPrice>()
                                }
                        };

                        #region Totales por Linea
                        /* 18 - Afectación al IGV por ítem */
                        linea.TaxTotals.Add(new TaxTotal
                        {
                            TaxAmount = new PayableAmount
                            {
                                currencyID = documento.F30_0_DocumentCurrencyCode,
                                value = detalleFactura.F18_0_IGVTaxAmount.Value
                            },
                            TaxSubtotal = new TaxSubtotal
                            {
                                TaxAmount = new PayableAmount
                                {
                                    currencyID = documento.F30_0_DocumentCurrencyCode,
                                    value = detalleFactura.F18_1_IGVTaxSubtotalAmount.Value
                                },
                                TaxCategory = new TaxCategory
                                {
                                    ID = "IGV",
                                    TaxExemptionReasonCode = Convert.ToInt32(detalleFactura.F18_2_IGVTaxExemptionReasonCode),
                                    TaxScheme = new TaxScheme()
                                    {
                                        ID = detalleFactura.F18_3_IGVTaxSchemeID.Trim(),
                                        Name = detalleFactura.F18_4_IGVTaxSchemeName.Trim(),
                                        TaxTypeCode = detalleFactura.F18_5_IGVTaxSchemeTaxTypeCode.Trim()
                                    }
                                }
                            }
                        });

                        /* 19 - Sistema de ISC por ítem */
                        if (detalleFactura.F19_0_ISCTaxAmount.HasValue)
                            linea.TaxTotals.Add(new TaxTotal
                            {
                                TaxAmount = new PayableAmount
                                {
                                    currencyID = documento.F30_0_DocumentCurrencyCode,
                                    value = detalleFactura.F19_0_ISCTaxAmount.Value
                                },
                                TaxSubtotal = new TaxSubtotal
                                {
                                    TaxAmount = new PayableAmount
                                    {
                                        currencyID = documento.F30_0_DocumentCurrencyCode,
                                        value = detalleFactura.F19_1_ISCTaxSubtotalAmount.Value
                                    },
                                    TaxCategory = new TaxCategory
                                    {
                                        ID = "ISC",
                                        TierRange = detalleFactura.F19_2_ISCTierRange.Trim(),
                                        TaxScheme = new TaxScheme()
                                        {
                                            ID = detalleFactura.F19_3_ISCTaxSchemeID.Trim(),
                                            Name = detalleFactura.F19_4_ISCTaxSchemeName.Trim(),
                                            TaxTypeCode = detalleFactura.F19_5_ISCTaxSchemeTaxTypeCode.Trim()
                                        }
                                    }
                                }
                            });
                        /* 35 - Valor referencial unitario
                                por ítem en operaciones no
                                onerosas y código (OPCIONAL) */
                        if (detalleFactura.F35_0_AlternativePriceAmount.HasValue)
                            linea.PricingReference.AlternativeConditionPrices.Add(new AlternativeConditionPrice
                            {
                                PriceAmount = new PayableAmount
                                {
                                    currencyID = documento.F30_0_DocumentCurrencyCode,
                                    value = detalleFactura.F17_0_PriceReferenceAmount.Value
                                },
                                PriceTypeCode = detalleFactura.F35_1_AlternativePriceTypeCode
                            });

                        // Para el caso del Valor Referencial.
                        if (detalleFactura.F35_0_AlternativePriceAmount.HasValue && detalleFactura.F35_1_AlternativePriceTypeCode == "02")
                        {
                            linea.PricingReference.AlternativeConditionPrices.Add(new AlternativeConditionPrice
                            {
                                PriceAmount = new PayableAmount
                                {
                                    currencyID = documento.F30_0_DocumentCurrencyCode,
                                    value = detalleFactura.F35_0_AlternativePriceAmount.Value
                                },
                                PriceTypeCode = detalleFactura.F35_1_AlternativePriceTypeCode.Trim()
                            });
                        }
                        notaCredito.CreditNoteLines.Add(linea);
                        #endregion
                    }
                    #endregion

                    #endregion

                    //UploadToAzureAsync(documento.F06_0_SuplierCustomerAssignedAccountID, notaCredito, nombreArchivo).Wait();

                    // Lo enviamos a SUNAT inmediatamente.
                    //var rpt = ProcesarDocumentoEnSunat(new DTOEnvioDocumentoRequest
                    //{
                    //    NombreArchivo = nombreArchivo,
                    //    NombreBaseDatos = request.NombreBaseDatos,
                    //    RucEmisor = nombreArchivo.Substring(0, 11),
                    //});

                    //response.NombreArchivo = nombreArchivo;
                    //response.Respuesta.Codigo = rpt.Respuesta.Codigo;
                    //response.Respuesta.Mensaje = rpt.Respuesta.Mensaje;
                }
            }
            #region Control de Excepciones
            catch (DbEntityValidationException ex)
            {
                var sb = new StringBuilder();

                foreach (var failure in ex.EntityValidationErrors)
                {
                    sb.AppendFormat("{0} Errores de Validación\n", failure.Entry.Entity.GetType());
                    foreach (var error in failure.ValidationErrors)
                    {
                        sb.AppendFormat("- {0} : {1}", error.PropertyName, error.ErrorMessage);
                        sb.AppendLine();
                    }
                }

                response.Respuesta.Codigo = ErrorValidacion.Codigo;
                response.Respuesta.Mensaje = ErrorValidacion.Mensaje;
                response.Respuesta.MensajeTecnico = sb.ToString();
                sb.Length = 0;
                response.Respuesta.PilaLlamadas = ex.StackTrace;
                response.GrabarLog();
            }
            catch (DbUpdateException ex)
            {
                response.Respuesta.Codigo = ErrorBaseDatos.Codigo;
                response.Respuesta.Mensaje = ErrorBaseDatos.Mensaje;
                response.Respuesta.MensajeTecnico = $"{ex.GetType().Name} {DesenredarException(ex)}";
                response.Respuesta.PilaLlamadas = ex.StackTrace;
                response.GrabarLog();
            }
            catch (Exception ex)
            {
                response.Respuesta.Codigo = ErrorGenerico.Codigo;
                response.Respuesta.Mensaje = ErrorGenerico.Mensaje;
                response.Respuesta.MensajeTecnico = $"{ex.GetType().Name} {DesenredarException(ex)}";
                response.Respuesta.PilaLlamadas = ex.StackTrace;
                response.GrabarLog();
            }
            #endregion
            return response;
        }

    }
}