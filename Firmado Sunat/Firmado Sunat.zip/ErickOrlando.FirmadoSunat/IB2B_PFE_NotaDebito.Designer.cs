﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ErickOrlando.Entidades
{
    public partial class IB2B_PFE_NotaDebito : IEquatable<IB2B_PFE_NotaDebito>
    {
        public bool Equals(IB2B_PFE_NotaDebito other)
        {
            return string.Concat(other.F07_0_ReferenceID, other.F08_0_SerieCorrelativo)
                .Equals(string.Concat(F07_0_ReferenceID, F08_0_SerieCorrelativo));
        }
        public override int GetHashCode()
        {
            return string.Concat(F07_0_ReferenceID, F08_0_SerieCorrelativo).GetHashCode();
        }

        public override string ToString()
        {
            return ROW_ID.ToString();
        }
    }

    public class ComparadorNotaDebito : IEqualityComparer<IB2B_PFE_NotaDebito>
    {
        public bool Equals(IB2B_PFE_NotaDebito x, IB2B_PFE_NotaDebito y)
        {
            return string.Concat(x.F07_0_ReferenceID, x.F08_0_SerieCorrelativo)
                .Equals(string.Concat(y.F07_0_ReferenceID, y.F08_0_SerieCorrelativo));
        }

        public int GetHashCode(IB2B_PFE_NotaDebito obj)
        {
            return string.Concat(obj.F07_0_ReferenceID, obj.F08_0_SerieCorrelativo).GetHashCode();
        }
    }
}
