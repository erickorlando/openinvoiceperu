﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ErickOrlando.Entidades
{
    public partial class GP_CE_TRX_RETENCION
    {
        public string TIPOIMPRESION { get; set; }
        public string REFERENCIA { get; set; }
    }
}
